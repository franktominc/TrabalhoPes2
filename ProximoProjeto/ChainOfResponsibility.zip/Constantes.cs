﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProximoProjeto {
    public static class Constantes {
        public static double SalarioMinimo = 800;
    }
}
